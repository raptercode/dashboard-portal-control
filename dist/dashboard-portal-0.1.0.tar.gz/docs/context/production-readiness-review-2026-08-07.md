# Production readiness review: 2026-08-07

## Corrected finding: live tool inventory

**Finding:** The host dashboard showed Nginx, Certbot, and Git as missing even though their executables were installed. `doctorReport()` returned the tool records persisted when the state file was created. Those records are installation history, not host truth.

**Correction:** In `host` mode, every `/api/doctor` request now probes fixed Ubuntu executable paths and returns the observed status and version. The persisted state remains useful for audit history, but cannot make the dashboard claim a missing tool is present or vice versa. Docker is considered installed only when both `docker --version` and `docker compose version` succeed.

**Regression evidence:** The test suite covers a stale state where Nginx, Git, and Docker probe as installed while Certbot does not. Live production API verification returned `Installed` for Nginx, Certbot, Git, Docker Engine, and Docker Compose.

## Accepted production controls

- Dashboard listens only on loopback; host Nginx handles public HTTPS.
- The owner cookie is `Secure`, `HttpOnly`, and `SameSite=Strict`; write routes require a CSRF token.
- Owner sessions persist for seven days across a normal Dashboard service restart. Persistent state stores only a hash of the browser session identifier; see ADR 0013.
- The public Nginx site sends `Referrer-Policy: no-referrer` so a URL query cannot be propagated as a referrer to later page assets or navigations.
- The direct installer verifies its Node archive, owns only its Nginx site, snapshots its own files before changes, and fails closed on TLS.
- Credentials and per-project environment content are encrypted at rest and API responses return metadata only.

## Remaining production gaps

These are not hidden by the corrected inventory screen and must be completed before relying on the portal to deploy arbitrary application projects:

1. **Privileged tool installer:** host-mode UI installation calls `HOSTMGR_HELPER_PATH`, but the direct installer does not provision a reviewed root helper or narrow execution bridge. Existing tools now report correctly; a newly missing tool will not be installable from the UI until this is implemented.
2. **Project activation:** candidate builds and health checks exist, but release activation/rollback deliberately stop at `awaiting_activation` without `HOSTMGR_DEPLOY_HELPER_PATH`. A reviewed helper must create the project Unix user, atomically switch the release, and restart only that project's systemd unit.
3. **SSH deploy keys:** SSH projects intentionally remain blocked until a key-generation, public-key registration, rotation, and revocation workflow is implemented.
4. **Isolation:** source clone/build code currently executes under the dashboard service account. Per-project user isolation must be moved into the privileged deployment workflow before hosting untrusted repositories.
5. **Operational acceptance:** the live host was not rebooted because it already serves unrelated workloads. Backups, restore, renewal monitoring, and a scheduled maintenance/reboot window remain operational work.

## Review conclusion

The Dashboard Portal itself is installed, HTTPS-protected, and accurately reports the tool inventory after this correction. It is suitable for owner access, Git configuration, encrypted credentials, and project metadata. It is not yet a complete multi-project production deployment platform until the four deployment-boundary gaps above are closed.
